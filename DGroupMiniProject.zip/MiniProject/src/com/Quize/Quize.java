package com.Quize;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Quize {
	
	int id;
	String name;
	int score=0;
	int que_no=0;
	
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		Quize quize= new Quize();
		System.out.println("Java Mini Project-1: Quiz\nGroup: D [1. Nivas Takale 2. Gaurav Sawale 3. Prathmesh Rambhekar]");
		System.out.println("\nEnter 1 to Login into Test\nEnter 2 to check your last test result\nEnter 3 to check summary result");
		int choice1 =sc.nextInt();
		switch(choice1)
		{
		case 1:
				quize.login();
				quize.start();
				quize.showQue();
				System.out.println();
				quize.getReuslt();
				
			break;
			
		case 2:
			quize.login();
			quize.getReuslt();
			break;
			
		case 3:
			quize.getSummuryResult();
			break;
			
			
		}
	}
	
	
	public void login() 
	/*This method will take input as id & password 
	 * and will verified with the id & password saved in Database in Student_info table*/
	{
		Scanner sc= new Scanner(System.in);
		Connection con= Utility.getSqlConnection();
		
		int i=0;
		int j=0;
		int k=0;
			
			
			PreparedStatement stmt= null;
			ResultSet rs= null;
			try {
				
				while (j==0)
				{
					System.out.println("Enter your id: ('101' for Guest Login)");
					id= sc.nextInt();
					stmt= con.prepareStatement("select name from student_info where id=?"); 
					stmt.setInt(1, id);
					rs= stmt.executeQuery();
					if(rs.isBeforeFirst())
					{
						j++;
					}
					else
					{
						System.err.println("You have entered incorrect id:\n Enter 1 to retry\n Enter 2 to Register yourself & login agian");
						k= sc.nextInt();
						if(k==1)
						{
							
						}
						else if(k==2)
						{
							register();
						}
						else
						{
							System.out.println("Enter Correct choice");
						}
					}
				}
				
				
				System.out.println("Enter your Password: (guest for Guest Login)");
				String pwd= sc.next();
				while (i==0)
				{
					 //to get corresponding name & password for the entered id from database
				stmt= con.prepareStatement("select name, password from student_info where id=?"); 
				stmt.setInt(1, id);
				rs= stmt.executeQuery();
				while(rs.next())
				{
					name= rs.getString(1); 
					if (rs.getString(2).equals(pwd))  //to authenticate password 
					{
						System.out.println("Welcome "+ name + " !!!! You are Logged in Successfully !!!!");
						i++;
					}
					else
					{
						System.err.println("Wrong Passswod.. Please Enter Correct Password");
						pwd= sc.next();
					}
				}
				}
				
				
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			finally
			{
				try {
					con.close();
					stmt.close();
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				//sc.close();
				
			
		}
		
	}
	
	
	public void register()
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Your ID:");
		int id= sc.nextInt();
		System.out.println("Enter Your Name: ");
		String name= sc.next();
		System.out.println("Set password: ");
		String pwd= sc.next();
		
		Connection con= Utility.getSqlConnection();
		PreparedStatement stmt= null;
		try 
		{
			stmt= con.prepareStatement("insert into student_info values (?,?,?)");
			stmt.setInt(1, id);
			stmt.setString(2, name);
			stmt.setString(3, pwd);
			stmt.executeUpdate();
			System.out.println("You have registered sucussesfully...!!\n Please Login for the quiz:");
			
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
				stmt.close();
			} 
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void start()  // to take input from user to start quiz
	{
		Scanner sc= new Scanner(System.in);
		int i=0;
		String c;
		while(i ==0)
		{
		System.out.println("Enter any charater to Start the Quize: ");
		c= sc.next();
		if(c!=null)
		{
			System.out.println("Best Luck!! Your Firt Question is on your Screen....\n");
			i++;
		}
		else 
			System.out.println("Enter Any Valid character");
		}
		
	}
	
	public void showQue()
	{
		Connection con= Utility.getSqlConnection();
		
		/*to show random questions:
		 	*new Arraylist created
		 	*1 to 10 values insrted
		 	*shuffled the ArrayList so we will get random order each time
		 */
		ArrayList<Integer> intList = new ArrayList();
		for(int i=1; i<=10; i++)
			intList.add(i);
		Collections.shuffle(intList);
		
		PreparedStatement stmt= null;
		PreparedStatement stmt1= null;
		ResultSet rs= null;
		try {
			for (int i=1; i<=10; i++)
			{
				
				que_no=intList.get(i-1);
				stmt= con.prepareStatement("select que, option_A, option_B, option_C,option_D from questions where que_no=?");
				stmt.setInt(1,que_no);
				rs= stmt.executeQuery();
				while(rs.next())
				{
					//to show que
					System.out.println(i+". " + rs.getString(1));
					//to show options
					System.out.println("a. "+rs.getString(2)+"\tb. "+rs.getString(3)+"\tc. "+rs.getString(4)+
							"\td. "+rs.getString(5));
					validateAns();  //validateAns() called to check input answer
					System.out.println();
				}
			}
			
			//to store test result(score & grade) into results table w.r.t id
			stmt1= con.prepareStatement("insert into result (stud_id, score, grade) values (?,?,?)");
			stmt1.setInt(1, id);
			stmt1.setInt(2, score);
			if(score>=8 && score<=10)
			{
				stmt1.setString(3,"A");
			}
			else if(score>=6 && score<8)
			{
				stmt1.setString(3,"B");
			}
			else if(score==5)
			{
				stmt1.setString(3,"C");
			}
			else
			{
				stmt1.setString(3,"D");
			}
			stmt1.executeUpdate();
			System.out.println("Test Completed Successfully....");
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
				
				stmt.close();
				rs.close();
				//stmt1.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	}
	
	
	
	}
	
	public void validateAns()
	{
		Connection con= Utility.getSqlConnection();
		int k=0;
		String ans=null;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Your Answer");
		do
		{
			ans= sc.next();
			if(ans.equals("a") || ans.equals("b") ||ans.equals("c") ||ans.equals("d"))
			{
				k++;
			}
			else
			{
				System.err.println("Please enter valid option: ");
			}
		}while(k==0);
		
		PreparedStatement stmt= null;
		ResultSet rs= null;
		try {
			stmt= con.prepareStatement("select ans from questions where que_no=?");
			stmt.setInt(1, que_no);
			rs= stmt.executeQuery();
			while(rs.next())
			{
				if(rs.getString(1).equals(ans))
				{
					score++;
				}

			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
				
				stmt.close();
				rs.close();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	public void getReuslt()    //to get last test result for a particular student from database
	{
		Connection con= Utility.getSqlConnection();
		PreparedStatement stmt= null;
		ResultSet rs= null;
		try {
			stmt= con.prepareStatement("select * from result where stud_id=? order by sr_no desc limit 1");
			stmt.setInt(1, id);
			rs= stmt.executeQuery();
			while(rs.next())
			{
				System.out.println("Your Marks are: "+rs.getInt(3));
			}
			}
		catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public void getSummuryResult()   // to get result summary table for all the students who completed test
	{
		Connection con = Utility.getSqlConnection();
		PreparedStatement stmt= null;
		ResultSet rs= null;
		try
		{
			stmt= con.prepareStatement("select id, name, score, grade from student_info left join result on student_info.id=result.stud_id order by id");
			rs= stmt.executeQuery();
			System.out.println("Stud_ID\t\tName\t\tScore\t\tgade");
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+"\t\t"+rs.getString(2)+"\t\t"+rs.getInt(3)+"\t\t"+rs.getString(4));
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}
}



